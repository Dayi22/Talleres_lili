def numeromayor(num3, num2):
    if num3 > num2:
        return num3
    else:
        return num2
numero1 = 40
numero2 = 70

mayornum = numeromayor(numero1, numero2)
print("El numero mayor es", mayornum)
