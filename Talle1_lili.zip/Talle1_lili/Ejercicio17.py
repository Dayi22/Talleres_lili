estudiantes = {
    'Daniel': 4.5,
    'Sergio': 5.0,
    'Carlos': 3.0,
    'Paula': 2.0,
    'Maria': 3.5
}


media = sum(estudiantes.values()) / len(estudiantes)


print(f'La calificación media es: {media}')

for estudiante, calificacion in estudiantes.items():
    diferencia = calificacion - media
    print(f'{estudiante}: {calificacion}, diferencia con la media: {diferencia}')
