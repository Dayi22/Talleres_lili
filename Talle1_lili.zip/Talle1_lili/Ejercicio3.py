import math

num1 = 20
num2 = 50

mcd = math.gcd(num1, num2)

print("El maximo comun divisor de", num1, "y", num2, "es:", mcd)    
