def potencia(x, n):
    return x ** n
x = 3.8
n = 60

resultado = potencia(x, n)
print("El resultado de", x, "elevado a la potencia", n, "es:", resultado)
