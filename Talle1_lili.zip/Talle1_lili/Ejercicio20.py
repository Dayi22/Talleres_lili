def fusionar_cadenas(mayuscula, minuscula):
    
    mayuscula = mayuscula.upper()
    minuscula = minuscula.lower()
    
    
    cadena_fusionada = mayuscula + minuscula
    
    return cadena_fusionada


cadena_mayuscula = "Hola\n"
cadena_minuscula = "¿Que haces?\n"

resultado = fusionar_cadenas(cadena_mayuscula, cadena_minuscula)
print(resultado)
