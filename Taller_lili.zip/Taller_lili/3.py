numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Acceder al tercer elemento 
tercer_elemento = numeros[2]

print("El tercer elemento de la lista números es:", tercer_elemento)