persona = {
    "nombre": "Dayana",
    "edad": 18,
    "ciudad": "Medellin"
}

# Elimina la clave "ciudad" 
del persona["ciudad"]

print("el diccionario después de eliminar la clave 'ciudad' es:", persona)