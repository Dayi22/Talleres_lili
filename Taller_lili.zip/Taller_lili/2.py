mixta = ['Hola, ¿que haces?', 10, 3.14]

print(mixta)