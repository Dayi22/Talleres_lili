persona = {
    "nombre": "Dayana",
    "edad": 18,
    "ciudad": "Medellin"
}

pares = list(persona.items())

print(pares)