

numeros_ordenados=[10,9,8,7,6,5,4,3,2,1]


numeros_ordenados.sort()

print(numeros_ordenados)