persona = {
    "nombre": "Dayana",
    "edad": 18,
    "ciudad": "Medellin"
}

claves = []

for clave in persona:
    claves.append(clave)

print(claves)