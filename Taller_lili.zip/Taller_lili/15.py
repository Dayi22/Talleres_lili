persona = {
    "nombre": "Dayana",
    "edad": 18,
    "ciudad": "Medellin"
}

valores = list(persona.values())

print(valores)