persona = {
    "nombre": "Dayana",
    "edad": 18,
    "ciudad": "Medellin"
}

print("Nombre:", persona["nombre"])
print("Edad:", persona["edad"])
print("Ciudad:", persona["ciudad"])