numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Eliminar el número 3
numeros.remove(3)

print("La lista números actualizada es:", numeros)