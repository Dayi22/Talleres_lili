persona = {
    "nombre": "Dayana",
    "edad": 18,
    "ciudad": "Medellin"
}

# Modifica el valor de la clave "edad" 
persona["edad"] = 38
print("La persona después de modificar la clave 'edad' es:", persona)