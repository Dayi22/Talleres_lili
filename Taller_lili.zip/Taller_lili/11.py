persona = {
    "nombre": "Dayana",
    "edad": 18,
    "ciudad": "Medellin"
}

# Accede al valor de la clave "edad" 
edad = persona["edad"]

print("La edad de la persona es:", edad)