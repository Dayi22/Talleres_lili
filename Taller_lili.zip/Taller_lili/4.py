numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Acceder al último elemento 
ultimo_elemento = numeros[-1]

print("El último elemento de la lista números es:", ultimo_elemento)