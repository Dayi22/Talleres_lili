meses = ('enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio',
         'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre')

# Accede al segundo meses
segundo_mes = meses[1]

print("El segundo mes del año es:", segundo_mes)