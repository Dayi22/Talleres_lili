numeros_pares=[x for x in range (1,11) if x %2==0]

print(numeros_pares)